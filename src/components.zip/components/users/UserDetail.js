import React from "react";

const UserDetail = () => {
  return (
    <div className="card">
      <h2>User Detail</h2>
      <p>This is the user detail page. (To be implemented)</p>
    </div>
  );
};

export default UserDetail;
