import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import { FaSearch, FaUser, FaMapMarkerAlt } from "react-icons/fa";
import LoadingSpinner from "../common/LoadingSpinner";

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async (skill = "") => {
    try {
      const response = await axios.get(
        `/api/users${skill ? `?skill=${skill}` : ""}`
      );
      setUsers(response.data);
    } catch (error) {
      toast.error("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchUsers(searchTerm);
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="card">
        <h2>Browse Users</h2>
        <p>Find people with skills you want to learn from</p>

        <form onSubmit={handleSearch} style={{ marginBottom: "20px" }}>
          <div style={{ display: "flex", gap: "10px" }}>
            <input
              type="text"
              placeholder="Search by skill (e.g., Photoshop, Excel, Cooking)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="form-control"
              style={{ flex: 1 }}
            />
            <button type="submit" className="btn btn-primary">
              <FaSearch /> Search
            </button>
          </div>
        </form>

        {searchTerm && (
          <button
            onClick={() => {
              setSearchTerm("");
              fetchUsers();
            }}
            className="btn btn-secondary"
            style={{ marginBottom: "20px" }}
          >
            Clear Search
          </button>
        )}
      </div>

      <div className="grid grid-2">
        {users.map((user) => (
          <div key={user.id} className="card">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "15px",
              }}
            >
              {user.profile_photo ? (
                <img
                  src={user.profile_photo}
                  alt={user.name}
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    marginRight: "15px",
                  }}
                />
              ) : (
                <div
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    backgroundColor: "#007bff",
                    color: "white",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "1.5rem",
                    marginRight: "15px",
                  }}
                >
                  <FaUser />
                </div>
              )}
              <div>
                <h3>{user.name}</h3>
                <p style={{ color: "#666", margin: 0 }}>@{user.username}</p>
              </div>
            </div>

            {user.location && (
              <p style={{ marginBottom: "10px" }}>
                <FaMapMarkerAlt style={{ marginRight: "5px" }} />
                {user.location}
              </p>
            )}

            {user.availability && (
              <p
                style={{
                  marginBottom: "15px",
                  fontSize: "0.9rem",
                  color: "#666",
                }}
              >
                <strong>Available:</strong> {user.availability}
              </p>
            )}

            <Link to={`/users/${user.id}`} className="btn btn-primary">
              View Profile
            </Link>
          </div>
        ))}
      </div>

      {users.length === 0 && !loading && (
        <div className="card" style={{ textAlign: "center" }}>
          <p>No users found. Try adjusting your search terms.</p>
        </div>
      )}
    </div>
  );
};

export default UserList;
