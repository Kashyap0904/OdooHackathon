import React from "react";

const AdminPanel = () => {
  return (
    <div className="card">
      <h2>Admin Panel</h2>
      <p>This is the admin panel. (To be implemented)</p>
    </div>
  );
};

export default AdminPanel;
