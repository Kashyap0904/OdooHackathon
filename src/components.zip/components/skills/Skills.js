import React from "react";

const Skills = () => {
  return (
    <div className="card">
      <h2>Skills</h2>
      <p>This is the skills management page. (To be implemented)</p>
    </div>
  );
};

export default Skills;
