import React from "react";

const Swaps = () => {
  return (
    <div className="card">
      <h2>Swaps</h2>
      <p>This is the swaps management page. (To be implemented)</p>
    </div>
  );
};

export default Swaps;
