import React from "react";

const Profile = () => {
  return (
    <div className="card">
      <h2>Profile</h2>
      <p>This is the user profile page. (To be implemented)</p>
    </div>
  );
};

export default Profile;
